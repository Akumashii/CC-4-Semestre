# contador de caracteres

frase = input()

print(len(frase))
